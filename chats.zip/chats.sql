CREATE TABLE users (
    i INT NOT NULL AUTO_INCREMENT,
	id INT NOT NULL,
    pw varchar(20) NOT NULL,
    nickname varchar(20) NOT NULL,
    imglink varchar(80),
    statemsg varchar(80),
    dropout TINYINT NOT NULL DEFAULT 0,
    regdate DATETIME NOT NULL,

    PRIMARY KEY(i)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE channels (
    i INT NOT NULL AUTO_INCREMENT,
	cname varchar(20) NOT NULL,
    user varchar(20) NOT NULL,
    link varchar(80) NOT NULL,
    num INT NOT NULL,
    dropout TINYINT NOT NULL DEFAULT 0,
    gendate DATETIME NOT NULL,

    PRIMARY KEY(i),
    FOREIGN KEY(user),
    REFERENCES users(i) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE chats (
	content varchar(80) NOT NULL,
    writer varchar(20) NOT NULL,
    channel varchar(20) NOT NULL,
    chatdate DATETIME NOT NULL,

    FOREIGN KEY(user),
    FOREIGN KEY(channel),
    REFERENCES users(i) ON DELETE CASCADE
    REFERENCES channels(i) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE blocks (
	doinguser varchar(20) NOT NULL,
    doneuser varchar(20) NOT NULL,
    blockdate DATETIME NOT NULL,

    FOREIGN KEY(doinguser),
    FOREIGN KEY(doneuser),
    REFERENCES users(i) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE follows (
	follower varchar(20) NOT NULL,
    followee varchar(20) NOT NULL,
    fdate DATETIME NOT NULL,

    FOREIGN KEY(follower),
    FOREIGN KEY(followee),
    REFERENCES users(i) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;