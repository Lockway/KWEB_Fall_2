const http = require('http');
const axios = require('axios');
const express = require('express'); 

const hostname = '127.0.0.1';
const port = 3000;
const app = express();


const server = http.createServer((req, res) => {
    res.statusCode = 200;
    res.setHeader('Content-Type', 'text/plain');
    
    
    axios({
        method: 'get',
        url: 'https://api.github.com/repos/nodejs/node',
        responseType: 'stream'
    })
        .then(function (response) {
            const {
                stargazers_count,
                forks_count,
                open_issues_count
            }=response;
        });


    try{
        app.get('/',(req,res)=>res.send(
            `Stargazers: ${stargazers_count}\n
            Forks: ${forks_count}\n
            Open Issues: ${open_issues_count}`
        ))
    }catch(e){
        res.statusCode=500;
        console.log('Internal error issued.');
    }
});

server.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
});